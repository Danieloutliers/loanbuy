/**
 * LoanBuddy - Módulo de Dados
 * Responsável por gerenciar o armazenamento e manipulação de dados
 */

// Namespace para funções de dados
const DataStore = {
  // Dados da aplicação
  borrowers: [],
  loans: [],
  payments: [],
  
  // Inicializar dados
  init() {
    console.log('Inicializando armazenamento de dados...');
    this.loadFromStorage();
  },
  
  // Carregar dados do localStorage
  loadFromStorage() {
    try {
      // Carregar mutuários
      const storedBorrowers = localStorage.getItem('borrowers');
      if (storedBorrowers) {
        this.borrowers = JSON.parse(storedBorrowers);
        console.log(`${this.borrowers.length} mutuários carregados`);
      } else {
        // Usar dados de exemplo se não existirem dados
        this.borrowers = this.getSampleBorrowers();
        this.saveToStorage('borrowers');
        console.log(`${this.borrowers.length} mutuários de exemplo carregados`);
      }
      
      // Carregar empréstimos
      const storedLoans = localStorage.getItem('loans');
      if (storedLoans) {
        this.loans = JSON.parse(storedLoans);
        console.log(`${this.loans.length} empréstimos carregados`);
      } else {
        // Usar dados de exemplo se não existirem dados
        this.loans = this.getSampleLoans();
        this.saveToStorage('loans');
        console.log(`${this.loans.length} empréstimos de exemplo carregados`);
      }
      
      // Carregar pagamentos
      const storedPayments = localStorage.getItem('payments');
      if (storedPayments) {
        this.payments = JSON.parse(storedPayments);
        console.log(`${this.payments.length} pagamentos carregados`);
      } else {
        // Usar dados de exemplo se não existirem dados
        this.payments = this.getSamplePayments();
        this.saveToStorage('payments');
        console.log(`${this.payments.length} pagamentos de exemplo carregados`);
      }
      
      // Carregar configurações
      const storedSettings = localStorage.getItem('settings');
      if (storedSettings) {
        AppState.settings = { ...AppState.settings, ...JSON.parse(storedSettings) };
        console.log('Configurações carregadas');
      }
    } catch (error) {
      console.error('Erro ao carregar dados do localStorage:', error);
    }
  },
  
  // Salvar dados no localStorage
  saveToStorage(dataType) {
    try {
      switch (dataType) {
        case 'borrowers':
          localStorage.setItem('borrowers', JSON.stringify(this.borrowers));
          console.log(`${this.borrowers.length} mutuários salvos`);
          break;
        case 'loans':
          localStorage.setItem('loans', JSON.stringify(this.loans));
          console.log(`${this.loans.length} empréstimos salvos`);
          break;
        case 'payments':
          localStorage.setItem('payments', JSON.stringify(this.payments));
          console.log(`${this.payments.length} pagamentos salvos`);
          break;
        case 'settings':
          localStorage.setItem('settings', JSON.stringify(AppState.settings));
          console.log('Configurações salvas');
          break;
        case 'all':
          this.saveToStorage('borrowers');
          this.saveToStorage('loans');
          this.saveToStorage('payments');
          this.saveToStorage('settings');
          break;
      }
    } catch (error) {
      console.error('Erro ao salvar dados no localStorage:', error);
    }
  },
  
  // MÉTODOS PARA MUTUÁRIOS
  
  // Obter todos os mutuários
  getBorrowers() {
    return this.borrowers;
  },
  
  // Obter um mutuário pelo ID
  getBorrower(id) {
    return this.borrowers.find(borrower => borrower.id === id);
  },
  
  // Adicionar um novo mutuário
  addBorrower(borrower) {
    // Gerar um ID único
    borrower.id = Date.now().toString();
    
    // Adicionar data de criação
    borrower.createdAt = new Date().toISOString();
    
    // Adicionar ao array
    this.borrowers.push(borrower);
    
    // Salvar no localStorage
    this.saveToStorage('borrowers');
    
    return borrower;
  },
  
  // Atualizar um mutuário
  updateBorrower(id, updates) {
    const index = this.borrowers.findIndex(borrower => borrower.id === id);
    
    if (index !== -1) {
      // Mesclar as atualizações com o mutuário existente
      this.borrowers[index] = { ...this.borrowers[index], ...updates, updatedAt: new Date().toISOString() };
      
      // Salvar no localStorage
      this.saveToStorage('borrowers');
      
      return this.borrowers[index];
    }
    
    return null;
  },
  
  // Excluir um mutuário
  deleteBorrower(id) {
    const initialLength = this.borrowers.length;
    this.borrowers = this.borrowers.filter(borrower => borrower.id !== id);
    
    // Se algo foi removido, salvar no localStorage
    if (initialLength !== this.borrowers.length) {
      this.saveToStorage('borrowers');
      return true;
    }
    
    return false;
  },
  
  // MÉTODOS PARA EMPRÉSTIMOS
  
  // Obter todos os empréstimos
  getLoans() {
    return this.loans;
  },
  
  // Obter um empréstimo pelo ID
  getLoan(id) {
    return this.loans.find(loan => loan.id === id);
  },
  
  // Obter empréstimos de um mutuário
  getLoansByBorrower(borrowerId) {
    return this.loans.filter(loan => loan.borrowerId === borrowerId);
  },
  
  // Adicionar um novo empréstimo
  addLoan(loan) {
    // Gerar um ID único
    loan.id = Date.now().toString();
    
    // Adicionar data de criação
    loan.createdAt = new Date().toISOString();
    
    // Definir status inicial como ativo
    loan.status = 'active';
    
    // Adicionar ao array
    this.loans.push(loan);
    
    // Salvar no localStorage
    this.saveToStorage('loans');
    
    return loan;
  },
  
  // Atualizar um empréstimo
  updateLoan(id, updates) {
    const index = this.loans.findIndex(loan => loan.id === id);
    
    if (index !== -1) {
      // Mesclar as atualizações com o empréstimo existente
      this.loans[index] = { ...this.loans[index], ...updates, updatedAt: new Date().toISOString() };
      
      // Salvar no localStorage
      this.saveToStorage('loans');
      
      return this.loans[index];
    }
    
    return null;
  },
  
  // Excluir um empréstimo
  deleteLoan(id) {
    const initialLength = this.loans.length;
    this.loans = this.loans.filter(loan => loan.id !== id);
    
    // Se algo foi removido, salvar no localStorage
    if (initialLength !== this.loans.length) {
      this.saveToStorage('loans');
      return true;
    }
    
    return false;
  },
  
  // MÉTODOS PARA PAGAMENTOS
  
  // Obter todos os pagamentos
  getPayments() {
    return this.payments;
  },
  
  // Obter um pagamento pelo ID
  getPayment(id) {
    return this.payments.find(payment => payment.id === id);
  },
  
  // Obter pagamentos de um empréstimo
  getPaymentsByLoan(loanId) {
    return this.payments.filter(payment => payment.loanId === loanId);
  },
  
  // Adicionar um novo pagamento
  addPayment(payment) {
    // Gerar um ID único
    payment.id = Date.now().toString();
    
    // Adicionar data de criação
    payment.createdAt = new Date().toISOString();
    
    // Adicionar ao array
    this.payments.push(payment);
    
    // Salvar no localStorage
    this.saveToStorage('payments');
    
    // Atualizar status do empréstimo se necessário
    this.updateLoanStatusAfterPayment(payment.loanId);
    
    return payment;
  },
  
  // Atualizar um pagamento
  updatePayment(id, updates) {
    const index = this.payments.findIndex(payment => payment.id === id);
    
    if (index !== -1) {
      // Mesclar as atualizações com o pagamento existente
      this.payments[index] = { ...this.payments[index], ...updates, updatedAt: new Date().toISOString() };
      
      // Salvar no localStorage
      this.saveToStorage('payments');
      
      // Atualizar status do empréstimo se necessário
      this.updateLoanStatusAfterPayment(this.payments[index].loanId);
      
      return this.payments[index];
    }
    
    return null;
  },
  
  // Excluir um pagamento
  deletePayment(id) {
    const payment = this.getPayment(id);
    const loanId = payment ? payment.loanId : null;
    
    const initialLength = this.payments.length;
    this.payments = this.payments.filter(payment => payment.id !== id);
    
    // Se algo foi removido, salvar no localStorage
    if (initialLength !== this.payments.length) {
      this.saveToStorage('payments');
      
      // Atualizar status do empréstimo se necessário
      if (loanId) {
        this.updateLoanStatusAfterPayment(loanId);
      }
      
      return true;
    }
    
    return false;
  },
  
  // MÉTODOS DE NEGÓCIOS
  
  // Atualizar status do empréstimo após um pagamento
  updateLoanStatusAfterPayment(loanId) {
    const loan = this.getLoan(loanId);
    if (!loan) return;
    
    // Obter todos os pagamentos deste empréstimo
    const loanPayments = this.getPaymentsByLoan(loanId);
    
    // Calcular o valor total pago
    const totalPaid = loanPayments.reduce((sum, payment) => sum + payment.amount, 0);
    
    // Obter o valor total do empréstimo + juros
    const totalLoanAmount = this.calculateTotalLoanAmount(loan);
    
    // Se o valor pago for igual ou maior que o valor total, marcar como pago
    if (totalPaid >= totalLoanAmount) {
      this.updateLoan(loanId, { status: 'paid', paidAt: new Date().toISOString() });
      return;
    }
    
    // Verificar se o empréstimo está em atraso
    const isOverdue = this.isLoanOverdue(loan);
    
    // Atualizar o status
    if (isOverdue) {
      // Verificar se está inadimplente (atraso > dias de carência)
      const daysOverdue = this.getLoanDaysOverdue(loan);
      const graceDays = AppState.settings.defaultGraceDays;
      
      if (daysOverdue > graceDays) {
        this.updateLoan(loanId, { status: 'defaulted' });
      } else {
        this.updateLoan(loanId, { status: 'overdue' });
      }
    } else {
      this.updateLoan(loanId, { status: 'active' });
    }
  },
  
  // Calcular valor total do empréstimo com juros
  calculateTotalLoanAmount(loan) {
    // Cálculo simples de juros para este exemplo
    // Em uma implementação real, você usaria a fórmula de juros compostos adequada
    const principal = loan.amount;
    const interestRate = loan.interestRate / 100; // Converter porcentagem para decimal
    const termMonths = loan.term;
    
    // Juros simples para este exemplo
    const interest = principal * interestRate * (termMonths / 12);
    return principal + interest;
  },
  
  // Verificar se um empréstimo está em atraso
  isLoanOverdue(loan) {
    if (loan.status === 'paid') return false;
    
    // Obter data atual
    const today = new Date();
    
    // Obter data de vencimento
    const dueDate = new Date(loan.dueDate);
    
    // Empréstimo está em atraso se a data atual é posterior à data de vencimento
    return today > dueDate;
  },
  
  // Obter dias em atraso
  getLoanDaysOverdue(loan) {
    if (loan.status === 'paid' || !this.isLoanOverdue(loan)) return 0;
    
    // Obter data atual
    const today = new Date();
    
    // Obter data de vencimento
    const dueDate = new Date(loan.dueDate);
    
    // Calcular diferença em dias
    const diffTime = Math.abs(today - dueDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  },
  
  // Obter empréstimos em atraso
  getOverdueLoans() {
    return this.loans.filter(loan => 
      loan.status === 'overdue' || loan.status === 'defaulted'
    );
  },
  
  // Obter próximos pagamentos
  getUpcomingPayments(days = 30) {
    // Obter data atual
    const today = new Date();
    
    // Data limite
    const limitDate = new Date(today);
    limitDate.setDate(today.getDate() + days);
    
    // Filtrar empréstimos ativos
    const activeLoans = this.loans.filter(loan => 
      loan.status === 'active' || loan.status === 'overdue'
    );
    
    // Criar lista de próximos pagamentos
    const upcomingPayments = [];
    
    activeLoans.forEach(loan => {
      // Obter mutuário
      const borrower = this.getBorrower(loan.borrowerId);
      if (!borrower) return;
      
      // Obter próxima data de pagamento
      const nextPaymentDate = new Date(loan.nextPaymentDate || loan.dueDate);
      
      // Se a data estiver dentro do período
      if (nextPaymentDate >= today && nextPaymentDate <= limitDate) {
        // Calcular valor do pagamento
        const paymentAmount = this.calculateLoanPaymentAmount(loan);
        
        upcomingPayments.push({
          id: `upcoming-${loan.id}`,
          loanId: loan.id,
          borrowerId: loan.borrowerId,
          borrowerName: borrower.name,
          amount: paymentAmount,
          date: nextPaymentDate.toISOString(),
          days: Math.ceil((nextPaymentDate - today) / (1000 * 60 * 60 * 24))
        });
      }
    });
    
    // Ordenar por data
    return upcomingPayments.sort((a, b) => new Date(a.date) - new Date(b.date));
  },
  
  // Calcular valor da parcela de um empréstimo
  calculateLoanPaymentAmount(loan) {
    // Cálculo simples para este exemplo
    const principal = loan.amount;
    const interestRate = loan.interestRate / 100; // Converter porcentagem para decimal
    const termMonths = loan.term;
    
    // Juros simples para este exemplo
    const interest = principal * interestRate * (termMonths / 12);
    const totalAmount = principal + interest;
    
    // Valor da parcela
    return totalAmount / termMonths;
  },
  
  // Obter métricas do dashboard
  getDashboardMetrics() {
    // Total emprestado
    const totalLoaned = this.loans.reduce((sum, loan) => sum + loan.amount, 0);
    
    // Total de juros acumulados
    const totalInterestAccrued = this.loans.reduce((sum, loan) => {
      const interest = loan.amount * (loan.interestRate / 100) * (loan.term / 12);
      return sum + interest;
    }, 0);
    
    // Pagamentos recebidos este mês
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    
    const paymentsThisMonth = this.payments.filter(payment => {
      const paymentDate = new Date(payment.date);
      return paymentDate >= firstDayOfMonth && paymentDate <= lastDayOfMonth;
    });
    
    const totalReceivedThisMonth = paymentsThisMonth.reduce((sum, payment) => sum + payment.amount, 0);
    
    // Total em atraso
    const overdueLoans = this.getOverdueLoans();
    const totalOverdue = overdueLoans.reduce((sum, loan) => {
      const payments = this.getPaymentsByLoan(loan.id);
      const totalPaid = payments.reduce((paidSum, payment) => paidSum + payment.amount, 0);
      const totalDue = this.calculateTotalLoanAmount(loan);
      return sum + (totalDue - totalPaid);
    }, 0);
    
    // Dados de empréstimos por status
    const loansByStatus = {
      active: this.loans.filter(loan => loan.status === 'active').length,
      overdue: this.loans.filter(loan => loan.status === 'overdue').length,
      defaulted: this.loans.filter(loan => loan.status === 'defaulted').length,
      paid: this.loans.filter(loan => loan.status === 'paid').length
    };
    
    return {
      totalLoaned,
      totalInterestAccrued,
      totalReceivedThisMonth,
      totalOverdue,
      loansByStatus
    };
  },
  
  // DADOS DE EXEMPLO
  
  // Dados de exemplo para mutuários
  getSampleBorrowers() {
    return [
      {
        id: '1',
        name: 'João Silva',
        email: 'joao.silva@email.com',
        phone: '(11) 98765-4321',
        cpf: '123.456.789-00',
        address: 'Rua A, 123',
        city: 'São Paulo',
        createdAt: '2025-04-01T10:00:00.000Z'
      },
      {
        id: '2',
        name: 'Maria Santos',
        email: 'maria.santos@email.com',
        phone: '(11) 98765-1234',
        cpf: '987.654.321-00',
        address: 'Rua B, 456',
        city: 'São Paulo',
        createdAt: '2025-04-05T14:30:00.000Z'
      },
      {
        id: '3',
        name: 'Pedro Oliveira',
        email: 'pedro.oliveira@email.com',
        phone: '(21) 99876-5432',
        cpf: '456.789.123-00',
        address: 'Av. C, 789',
        city: 'Rio de Janeiro',
        createdAt: '2025-04-10T09:15:00.000Z'
      }
    ];
  },
  
  // Dados de exemplo para empréstimos
  getSampleLoans() {
    const today = new Date();
    
    // Empréstimo 1 - Ativo
    const loan1StartDate = new Date('2025-05-01');
    const loan1DueDate = new Date('2026-05-01');
    
    // Empréstimo 2 - Em atraso
    const loan2StartDate = new Date('2025-04-27');
    const loan2DueDate = new Date('2026-04-27');
    
    // Empréstimo 3 - Ativo
    const loan3StartDate = new Date('2025-04-15');
    const loan3DueDate = new Date('2026-04-15');
    
    return [
      {
        id: '1',
        borrowerId: '1',
        amount: 5000,
        interestRate: 5,
        term: 12, // meses
        startDate: loan1StartDate.toISOString(),
        dueDate: loan1DueDate.toISOString(),
        nextPaymentDate: new Date('2025-05-07').toISOString(),
        paymentFrequency: 'monthly',
        description: 'Empréstimo para reforma residencial',
        status: 'active',
        createdAt: loan1StartDate.toISOString()
      },
      {
        id: '2',
        borrowerId: '2',
        amount: 10000,
        interestRate: 5,
        term: 12, // meses
        startDate: loan2StartDate.toISOString(),
        dueDate: loan2DueDate.toISOString(),
        nextPaymentDate: new Date('2025-04-27').toISOString(), // Atrasado
        paymentFrequency: 'monthly',
        description: 'Empréstimo para compra de automóvel',
        status: 'overdue',
        createdAt: loan2StartDate.toISOString()
      },
      {
        id: '3',
        borrowerId: '3',
        amount: 20000,
        interestRate: 5,
        term: 24, // meses
        startDate: loan3StartDate.toISOString(),
        dueDate: loan3DueDate.toISOString(),
        nextPaymentDate: new Date('2025-06-02').toISOString(),
        paymentFrequency: 'monthly',
        description: 'Empréstimo para negócio',
        status: 'active',
        createdAt: loan3StartDate.toISOString()
      }
    ];
  },
  
  // Dados de exemplo para pagamentos
  getSamplePayments() {
    return [
      {
        id: '1',
        loanId: '1',
        amount: 437.50,
        date: '2025-04-01T10:30:00.000Z',
        method: 'transfer',
        type: 'scheduled',
        notes: 'Primeiro pagamento',
        createdAt: '2025-04-01T10:30:00.000Z'
      },
      {
        id: '2',
        loanId: '2',
        amount: 525.00,
        date: '2025-03-27T14:45:00.000Z',
        method: 'cash',
        type: 'scheduled',
        notes: 'Primeiro pagamento',
        createdAt: '2025-03-27T14:45:00.000Z'
      },
      {
        id: '3',
        loanId: '3',
        amount: 866.67,
        date: '2025-03-15T09:20:00.000Z',
        method: 'pix',
        type: 'scheduled',
        notes: 'Primeiro pagamento',
        createdAt: '2025-03-15T09:20:00.000Z'
      },
      {
        id: '4',
        loanId: '1',
        amount: 437.50,
        date: '2025-05-07T10:00:00.000Z',
        method: 'transfer',
        type: 'scheduled',
        notes: 'Segundo pagamento',
        createdAt: '2025-05-07T10:00:00.000Z'
      },
      {
        id: '5',
        loanId: '3',
        amount: 866.67,
        date: '2025-04-15T11:30:00.000Z',
        method: 'pix',
        type: 'scheduled',
        notes: 'Segundo pagamento',
        createdAt: '2025-04-15T11:30:00.000Z'
      },
      {
        id: '6',
        loanId: '3',
        amount: 866.67,
        date: '2025-05-15T14:00:00.000Z',
        method: 'pix',
        type: 'scheduled',
        notes: 'Terceiro pagamento',
        createdAt: '2025-05-15T14:00:00.000Z'
      },
      {
        id: '7',
        loanId: '3',
        amount: 866.67,
        date: '2025-06-02T09:00:00.000Z',
        method: 'pix',
        type: 'scheduled',
        notes: 'Quarto pagamento',
        createdAt: '2025-06-02T09:00:00.000Z'
      }
    ];
  },
  
  // Exportar todos os dados
  exportAllData() {
    const data = {
      borrowers: this.borrowers,
      loans: this.loans,
      payments: this.payments,
      settings: AppState.settings,
      exportDate: new Date().toISOString()
    };
    
    return JSON.stringify(data, null, 2);
  },
  
  // Importar todos os dados
  importAllData(jsonData) {
    try {
      const data = JSON.parse(jsonData);
      
      if (data.borrowers) {
        this.borrowers = data.borrowers;
      }
      
      if (data.loans) {
        this.loans = data.loans;
      }
      
      if (data.payments) {
        this.payments = data.payments;
      }
      
      if (data.settings) {
        AppState.settings = { ...AppState.settings, ...data.settings };
      }
      
      // Salvar tudo no localStorage
      this.saveToStorage('all');
      
      return true;
    } catch (error) {
      console.error('Erro ao importar dados:', error);
      return false;
    }
  }
};

// Inicializar dados ao carregar o arquivo
DataStore.init();