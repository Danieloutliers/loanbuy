/**
 * LoanBuddy - Sistema de Gestão de Empréstimos
 * Aplicação HTML/CSS/JS pura
 */

// Estado Global da Aplicação
const AppState = {
  // Tema atual (light ou dark)
  theme: localStorage.getItem('theme') || 'light',
  
  // Página atual
  currentPage: 'dashboard',
  
  // Estado de conexão
  isOnline: navigator.onLine,
  
  // Estado de sincronização
  isSyncing: false,
  
  // Filtros
  filters: {
    loans: {
      status: 'all',
      sort: 'date-desc',
      search: ''
    },
    borrowers: {
      sort: 'name-asc',
      search: ''
    },
    payments: {
      period: 'all',
      sort: 'date-desc',
      search: ''
    }
  },
  
  // Configurações
  settings: {
    currency: 'BRL',
    dateFormat: 'DD/MM/YYYY',
    defaultInterestRate: 5,
    defaultPaymentPeriod: 'monthly',
    defaultGraceDays: 30,
    enableNotifications: true,
    paymentReminderDays: 3,
    notifyLatePayments: true,
    autoBackup: true
  }
};

// Inicializar a aplicação quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', initApp);

// Função de inicialização principal
function initApp() {
  console.log('Inicializando LoanBuddy...');
  
  // Aplicar tema salvo
  applyTheme();
  
  // Inicializar listeners de eventos
  setupEventListeners();
  
  // Inicializar componentes da UI
  UI.initializeUI();
  
  // Carregar dados
  loadData();
  
  // Inicializar gráficos
  Charts.initializeCharts();
  
  // Verificar estado de conexão
  updateConnectionStatus();
  
  console.log('LoanBuddy inicializado com sucesso!');
}

// Configurar listeners de eventos
function setupEventListeners() {
  // Navegação sidebar
  document.querySelectorAll('.sidebar-link').forEach(link => {
    link.addEventListener('click', handleNavigation);
  });
  
  // Navegação mobile
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', handleNavigation);
  });
  
  // Toggle menu mobile
  document.querySelector('.mobile-toggle').addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('active');
  });
  
  // Toggle tema
  document.querySelector('.theme-toggle').addEventListener('click', toggleTheme);
  
  // Links "Ver todos"
  document.querySelectorAll('.view-all').forEach(link => {
    link.addEventListener('click', handleNavigation);
  });
  
  // Ações rápidas
  document.querySelectorAll('.action-btn').forEach(btn => {
    btn.addEventListener('click', handleQuickAction);
  });
  
  // Botões de novo empréstimo
  document.getElementById('new-loan-btn')?.addEventListener('click', () => {
    showModal('loan-modal');
  });
  
  // Botões de novo mutuário
  document.getElementById('new-borrower-btn')?.addEventListener('click', () => {
    showModal('borrower-modal');
  });
  
  // Botões de novo pagamento
  document.getElementById('new-payment-btn')?.addEventListener('click', () => {
    showModal('payment-modal');
  });
  
  // Botões para fechar modais
  document.querySelectorAll('.close-modal, .cancel-modal').forEach(btn => {
    btn.addEventListener('click', closeAllModals);
  });
  
  // Formulários de modais
  document.getElementById('loan-form')?.addEventListener('submit', handleLoanForm);
  document.getElementById('borrower-form')?.addEventListener('submit', handleBorrowerForm);
  document.getElementById('payment-form')?.addEventListener('submit', handlePaymentForm);
  
  // Filtros
  document.getElementById('status-filter')?.addEventListener('change', applyLoanFilters);
  document.getElementById('sort-filter')?.addEventListener('change', applyLoanFilters);
  document.getElementById('borrower-sort-filter')?.addEventListener('change', applyBorrowerFilters);
  document.getElementById('period-filter')?.addEventListener('change', applyPaymentFilters);
  document.getElementById('payment-sort-filter')?.addEventListener('change', applyPaymentFilters);
  
  // Pesquisa
  document.querySelectorAll('.search-box input').forEach(input => {
    input.addEventListener('input', handleSearch);
  });
  
  // Toggle More Menu (mobile)
  document.querySelector('.nav-item[data-page="more"]')?.addEventListener('click', (e) => {
    e.preventDefault();
    document.querySelector('.more-menu').classList.add('active');
  });
  
  document.querySelector('.close-more-menu')?.addEventListener('click', () => {
    document.querySelector('.more-menu').classList.remove('active');
  });
  
  document.querySelector('.more-menu-backdrop')?.addEventListener('click', () => {
    document.querySelector('.more-menu').classList.remove('active');
  });
  
  // Eventos de conexão
  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);
  
  // Eventos de configurações
  document.getElementById('theme-select')?.addEventListener('change', handleThemeChange);
  document.getElementById('default-interest-rate')?.addEventListener('change', saveSettings);
  document.getElementById('default-payment-period')?.addEventListener('change', saveSettings);
  document.getElementById('default-grace-days')?.addEventListener('change', saveSettings);
  document.getElementById('notifications-toggle')?.addEventListener('change', saveSettings);
  document.getElementById('payment-reminder-days')?.addEventListener('change', saveSettings);
  document.getElementById('late-payment-toggle')?.addEventListener('change', saveSettings);
  document.getElementById('auto-backup-toggle')?.addEventListener('change', saveSettings);
  
  // Botões de exportar/importar dados
  document.getElementById('export-data-btn')?.addEventListener('click', exportData);
  document.getElementById('import-data-btn')?.addEventListener('click', importData);
  document.getElementById('clear-data-btn')?.addEventListener('click', clearAllData);
}

// Funções de navegação
function handleNavigation(e) {
  e.preventDefault();
  
  // Obter a página de destino
  let targetPage = this.dataset.page;
  
  // Se o target não existir, tentar obter do elemento pai
  if (!targetPage && this.parentElement) {
    targetPage = this.parentElement.dataset.page;
  }
  
  // Se ainda não existir, não fazer nada
  if (!targetPage) return;
  
  // Mudar para a página
  changePage(targetPage);
  
  // Se estiver em mobile, fechar sidebar
  document.querySelector('.sidebar')?.classList.remove('active');
  
  // Fechar o menu "more" se estiver aberto
  document.querySelector('.more-menu')?.classList.remove('active');
}

function changePage(page) {
  // Não fazer nada se já estiver na mesma página
  if (AppState.currentPage === page) return;
  
  console.log(`Mudando para a página: ${page}`);
  
  // Atualizar estado
  AppState.currentPage = page;
  
  // Atualizar classes active nas links
  document.querySelectorAll('.sidebar-link').forEach(link => {
    link.classList.toggle('active', link.dataset.page === page);
  });
  
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.page === page);
  });
  
  // Ocultar todas as páginas
  document.querySelectorAll('.page').forEach(pageEl => {
    pageEl.classList.remove('active');
  });
  
  // Mostrar a página desejada
  const targetPage = document.getElementById(`${page}-page`);
  if (targetPage) {
    targetPage.classList.add('active');
  }
  
  // Atualizar título da página
  updatePageTitle(page);
  
  // Atualizar URL (para suporte de histórico, opcional)
  window.history.pushState({ page }, '', `#${page}`);
}

function updatePageTitle(page) {
  let title = 'Dashboard';
  
  switch (page) {
    case 'loans': title = 'Empréstimos'; break;
    case 'borrowers': title = 'Mutuários'; break;
    case 'payments': title = 'Pagamentos'; break;
    case 'reports': title = 'Relatórios'; break;
    case 'settings': title = 'Configurações'; break;
    default: title = 'Dashboard';
  }
  
  document.querySelector('.page-title').textContent = title;
}

// Funções de tema
function applyTheme() {
  const theme = AppState.theme;
  document.body.className = theme === 'dark' ? 'dark-theme' : 'light-theme';
  
  // Atualizar ícone do botão de tema
  const themeToggle = document.querySelector('.theme-toggle i');
  if (themeToggle) {
    themeToggle.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
  }
  
  // Atualizar select nas configurações
  const themeSelect = document.getElementById('theme-select');
  if (themeSelect) {
    themeSelect.value = theme;
  }
  
  console.log(`Tema aplicado: ${theme}`);
}

function toggleTheme() {
  AppState.theme = AppState.theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('theme', AppState.theme);
  applyTheme();
}

function handleThemeChange(e) {
  const selectedTheme = e.target.value;
  AppState.theme = selectedTheme;
  localStorage.setItem('theme', selectedTheme);
  applyTheme();
}

// Funções para controle de modais
function showModal(modalId) {
  console.log(`Abrindo modal: ${modalId}`);
  
  // Fechar todos os modais primeiro
  closeAllModals();
  
  // Mostrar o modal desejado
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
    
    // Definir valores padrão nos formulários
    if (modalId === 'loan-modal') {
      setDefaultLoanFormValues();
    } else if (modalId === 'payment-modal') {
      setDefaultPaymentFormValues();
    }
  }
}

function closeAllModals() {
  document.querySelectorAll('.modal').forEach(modal => {
    modal.classList.remove('active');
  });
}

// Funções para manipulação de formulários
function setDefaultLoanFormValues() {
  const today = new Date();
  const startDateInput = document.getElementById('loan-start-date');
  const firstPaymentInput = document.getElementById('loan-first-payment');
  
  if (startDateInput) {
    startDateInput.valueAsDate = today;
  }
  
  if (firstPaymentInput) {
    // Definir data do primeiro pagamento para 30 dias após
    const nextMonth = new Date(today);
    nextMonth.setDate(today.getDate() + 30);
    firstPaymentInput.valueAsDate = nextMonth;
  }
  
  // Definir taxa de juros padrão
  const interestInput = document.getElementById('loan-interest');
  if (interestInput) {
    interestInput.value = AppState.settings.defaultInterestRate;
  }
  
  // Definir frequência de pagamento padrão
  const frequencySelect = document.getElementById('loan-payment-frequency');
  if (frequencySelect) {
    frequencySelect.value = AppState.settings.defaultPaymentPeriod;
  }
}

function setDefaultPaymentFormValues() {
  const today = new Date();
  const paymentDateInput = document.getElementById('payment-date');
  
  if (paymentDateInput) {
    paymentDateInput.valueAsDate = today;
  }
}

function handleLoanForm(e) {
  e.preventDefault();
  
  // Aqui você implementaria a lógica para salvar o empréstimo
  // Para este exemplo, vamos apenas mostrar uma notificação
  console.log('Formulário de empréstimo enviado');
  
  closeAllModals();
  showToast('Empréstimo criado com sucesso!', 'success');
  
  // Recarregar dados
  loadData();
}

function handleBorrowerForm(e) {
  e.preventDefault();
  
  // Aqui você implementaria a lógica para salvar o mutuário
  // Para este exemplo, vamos apenas mostrar uma notificação
  console.log('Formulário de mutuário enviado');
  
  closeAllModals();
  showToast('Mutuário criado com sucesso!', 'success');
  
  // Recarregar dados
  loadData();
}

function handlePaymentForm(e) {
  e.preventDefault();
  
  // Aqui você implementaria a lógica para salvar o pagamento
  // Para este exemplo, vamos apenas mostrar uma notificação
  console.log('Formulário de pagamento enviado');
  
  closeAllModals();
  showToast('Pagamento registrado com sucesso!', 'success');
  
  // Recarregar dados
  loadData();
}

// Funções para ações rápidas
function handleQuickAction(e) {
  const action = this.dataset.action;
  
  switch (action) {
    case 'new-loan':
      showModal('loan-modal');
      break;
    case 'new-borrower':
      showModal('borrower-modal');
      break;
    case 'register-payment':
      showModal('payment-modal');
      break;
    case 'generate-report':
      changePage('reports');
      break;
  }
}

// Funções para filtros
function applyLoanFilters() {
  const statusFilter = document.getElementById('status-filter').value;
  const sortFilter = document.getElementById('sort-filter').value;
  
  AppState.filters.loans.status = statusFilter;
  AppState.filters.loans.sort = sortFilter;
  
  // Aqui você implementaria a lógica para filtrar os empréstimos
  console.log(`Filtros de empréstimos aplicados: status=${statusFilter}, sort=${sortFilter}`);
  
  // Recarregar os dados com os novos filtros
  loadLoansData();
}

function applyBorrowerFilters() {
  const sortFilter = document.getElementById('borrower-sort-filter').value;
  
  AppState.filters.borrowers.sort = sortFilter;
  
  // Aqui você implementaria a lógica para filtrar os mutuários
  console.log(`Filtros de mutuários aplicados: sort=${sortFilter}`);
  
  // Recarregar os dados com os novos filtros
  loadBorrowersData();
}

function applyPaymentFilters() {
  const periodFilter = document.getElementById('period-filter').value;
  const sortFilter = document.getElementById('payment-sort-filter').value;
  
  AppState.filters.payments.period = periodFilter;
  AppState.filters.payments.sort = sortFilter;
  
  // Aqui você implementaria a lógica para filtrar os pagamentos
  console.log(`Filtros de pagamentos aplicados: period=${periodFilter}, sort=${sortFilter}`);
  
  // Recarregar os dados com os novos filtros
  loadPaymentsData();
}

function handleSearch(e) {
  const searchQuery = e.target.value.trim();
  const searchContext = e.target.closest('.search-box').parentElement.parentElement.id;
  
  if (searchContext.includes('loans')) {
    AppState.filters.loans.search = searchQuery;
    loadLoansData();
  } else if (searchContext.includes('borrowers')) {
    AppState.filters.borrowers.search = searchQuery;
    loadBorrowersData();
  } else if (searchContext.includes('payments')) {
    AppState.filters.payments.search = searchQuery;
    loadPaymentsData();
  }
}

// Funções para carregar dados
function loadData() {
  // Carregar dados para todas as seções
  loadDashboardData();
  loadLoansData();
  loadBorrowersData();
  loadPaymentsData();
}

function loadDashboardData() {
  console.log('Carregando dados do dashboard...');
  // Implementação real buscaria dados do localStorage ou API
}

function loadLoansData() {
  console.log('Carregando dados de empréstimos...');
  // Implementação real buscaria dados do localStorage ou API e aplicaria filtros
}

function loadBorrowersData() {
  console.log('Carregando dados de mutuários...');
  // Implementação real buscaria dados do localStorage ou API e aplicaria filtros
}

function loadPaymentsData() {
  console.log('Carregando dados de pagamentos...');
  // Implementação real buscaria dados do localStorage ou API e aplicaria filtros
}

// Funções para configurações
function saveSettings() {
  // Salvar todas as configurações do formulário no estado da aplicação
  AppState.settings.defaultInterestRate = parseFloat(document.getElementById('default-interest-rate').value);
  AppState.settings.defaultPaymentPeriod = document.getElementById('default-payment-period').value;
  AppState.settings.defaultGraceDays = parseInt(document.getElementById('default-grace-days').value);
  AppState.settings.enableNotifications = document.getElementById('notifications-toggle').checked;
  AppState.settings.paymentReminderDays = parseInt(document.getElementById('payment-reminder-days').value);
  AppState.settings.notifyLatePayments = document.getElementById('late-payment-toggle').checked;
  AppState.settings.autoBackup = document.getElementById('auto-backup-toggle').checked;
  
  // Salvar no localStorage
  localStorage.setItem('settings', JSON.stringify(AppState.settings));
  
  // Notificar usuário
  showToast('Configurações salvas com sucesso!', 'success');
}

// Funções para exportar/importar dados
function exportData() {
  // Implementação real exportaria todos os dados para um arquivo
  console.log('Exportando dados...');
  
  showToast('Dados exportados com sucesso!', 'success');
}

function importData() {
  // Implementação real importaria dados de um arquivo
  console.log('Importando dados...');
  
  showToast('Dados importados com sucesso!', 'success');
}

function clearAllData() {
  // Implementação real limparia todos os dados do localStorage após confirmação
  if (confirm('Tem certeza que deseja limpar todos os dados? Esta ação é irreversível.')) {
    console.log('Limpando todos os dados...');
    
    // Limpar dados do localStorage
    localStorage.removeItem('borrowers');
    localStorage.removeItem('loans');
    localStorage.removeItem('payments');
    
    // Recarregar dados
    loadData();
    
    showToast('Todos os dados foram limpos!', 'info');
  }
}

// Funções para notificações
function showToast(message, type = 'info') {
  // Criar elemento de toast
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  
  // Definir ícone com base no tipo
  let icon = 'info-circle';
  let title = 'Informação';
  
  switch (type) {
    case 'success':
      icon = 'check-circle';
      title = 'Sucesso';
      break;
    case 'warning':
      icon = 'exclamation-circle';
      title = 'Alerta';
      break;
    case 'error':
      icon = 'times-circle';
      title = 'Erro';
      break;
  }
  
  // Estrutura do toast
  toast.innerHTML = `
    <div class="toast-icon"><i class="fas fa-${icon}"></i></div>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      <div class="toast-message">${message}</div>
    </div>
    <div class="toast-close"><i class="fas fa-times"></i></div>
  `;
  
  // Adicionar ao container
  const container = document.querySelector('.toast-container');
  container.appendChild(toast);
  
  // Adicionar evento de fechar
  toast.querySelector('.toast-close').addEventListener('click', () => {
    toast.remove();
  });
  
  // Auto-remoção após 5 segundos
  setTimeout(() => {
    toast.classList.add('toast-hiding');
    setTimeout(() => toast.remove(), 300);
  }, 5000);
}

// Funções para status de conexão
function updateConnectionStatus() {
  const isOnline = navigator.onLine;
  AppState.isOnline = isOnline;
  
  const offlineIndicator = document.querySelector('.offline-indicator');
  if (offlineIndicator) {
    offlineIndicator.style.display = isOnline ? 'none' : 'block';
  }
  
  console.log(`Status de conexão: ${isOnline ? 'online' : 'offline'}`);
}

function handleOnline() {
  updateConnectionStatus();
  showToast('Conexão restabelecida!', 'success');
  
  // Implementação real sincronizaria dados pendentes
  syncData();
}

function handleOffline() {
  updateConnectionStatus();
  showToast('Você está offline. Algumas funções podem estar limitadas.', 'warning');
}

// Sincronização de dados
function syncData() {
  if (!AppState.isOnline) {
    console.log('Não é possível sincronizar: offline');
    return;
  }
  
  if (AppState.isSyncing) {
    console.log('Já está sincronizando dados...');
    return;
  }
  
  console.log('Sincronizando dados...');
  AppState.isSyncing = true;
  
  // Atualizar visual do botão de sincronização
  const syncBtn = document.querySelector('.sync-status');
  if (syncBtn) {
    syncBtn.classList.add('syncing');
  }
  
  // Simulação de sincronização
  setTimeout(() => {
    AppState.isSyncing = false;
    
    // Atualizar visual do botão
    if (syncBtn) {
      syncBtn.classList.remove('syncing');
    }
    
    console.log('Sincronização concluída!');
    showToast('Dados sincronizados com sucesso!', 'success');
  }, 2000);
}

// Funções para histórico do navegador
window.addEventListener('popstate', (e) => {
  if (e.state && e.state.page) {
    changePage(e.state.page);
  }
});